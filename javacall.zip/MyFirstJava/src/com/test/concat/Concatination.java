package com.test.concat;

public class Concatination {

	/**
	 * @param args
	 */
	

public static String concatMethod(String FName, String LName) {
		return "Mr. " + FName + " " + LName;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(concatMethod("Naresh","N"));

	}

}
